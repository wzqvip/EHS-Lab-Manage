#ifndef __EPD_Display_h__
#define __EPD_Display_h__

#include <./epdlib/UC8151c_152x152.h>
#include <./epdlib/UC8154c_200X200.h>

#endif
