# EHS-GasCylinderManagement-System-Zigbee

你科EHS的实验室气瓶管理系统.

#### ***研发中***

当前 无盈利-non-commerical. 可能会fork一些其他项目做参考。

#### 介绍

###### 甲方的要求：

1. Zigbee组网,
2. 低功耗分布式,
3. 墨水屏显示设备状态.

###### 当前研发：

1. CC2530，Zigbee协议组网通讯
2. Arduino/ESP8266/ESP32/PICO2040芯片主控
   * 未确定C/Python语言
   * 平行进度 CC2530兼主控
3. 2.9寸2-3色墨水屏，当前选型MH(带排针)，魏雪的不带排针。
   * 后期考虑板载驱动板，使用裸屏
4. 外壳文件测试失败，重做中            
How to use：

At editor, open the document via: Top menu - File - Open - EasyEDA... , and select the json file, then open it at the editor, you can save it into a project.


如何使用：

打开编辑器，通过：顶部菜单 - 文件 - 打开 - 立创EDA... ，选择 json 文件打开在编辑器，你可以保存文档进工程里面。